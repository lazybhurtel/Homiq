/* ============================================
   HOMIQ — JAVASCRIPT
   ============================================
   FEATURES:
   • Sticky navbar scroll shrink
   • Mobile hamburger menu
   • FAQ accordion
   • Scroll-triggered fade animations
   • Form submission (Formspree or Google Forms)
   • Smooth scroll for anchor links
   • Booking date minimum = today
   ============================================

   FORM STRATEGY — CHOOSE ONE:

   OPTION A: FORMSPREE (Current setup)
   ------------------------------------
   1. Go to https://formspree.io/register
   2. Create two forms: one for Bookings, one for Applications
   3. Copy each form's endpoint URL (looks like: https://formspree.io/f/xxxxxxxx)
   4. Replace the URLs below in FORMSPREE_BOOKING_URL and FORMSPREE_APPLICATION_URL
   5. That's it — submissions arrive in your email instantly

   OPTION B: GOOGLE FORMS (Recommended if you prefer)
   --------------------------------------------------
   1. Go to https://forms.google.com and create two forms
   2. Get the embed iframe code (Send → Embed)
   3. In index.html, replace the <form> tags with the iframe code
   4. Set up email notifications in the Google Form (Responses → 3-dot menu → Get email notifications)
   5. Delete or comment out the handleBooking() and handleApplication() functions below

   OPTION C: NETLIFY FORMS (If hosting on Netlify)
   -------------------------------------------------
   1. Add data-netlify="true" to each <form> tag in index.html
   2. Add a hidden input: <input type="hidden" name="form-name" value="booking">
   3. Netlify handles everything — no JS needed for submission
   4. Delete or comment out the fetch code below

   ============================================ */

// ---------- FORMSPREE CONFIG (Option A) ----------
// Replace these with your actual Formspree form IDs
const FORMSPREE_BOOKING_URL = 'https://formspree.io/f/YOUR_BOOKING_FORM_ID';
const FORMSPREE_APPLICATION_URL = 'https://formspree.io/f/YOUR_APPLICATION_FORM_ID';

// If both forms should go to the same Formspree form, use one URL for both.
// The hidden _subject field in HTML tells them apart in your inbox.


/* ============================================
   1. HEADER SCROLL SHRINK
   Adds .scrolled class to header when user scrolls down
   ============================================ */
const header = document.getElementById('header');

window.addEventListener('scroll', () => {
  if (window.scrollY > 20) {
    header.classList.add('scrolled');
  } else {
    header.classList.remove('scrolled');
  }
});


/* ============================================
   2. MOBILE MENU TOGGLE
   Hamburger button opens/closes mobile dropdown
   ============================================ */
const mobileToggle = document.getElementById('mobileToggle');
const mobileMenu = document.getElementById('mobileMenu');

mobileToggle.addEventListener('click', () => {
  const isOpen = mobileMenu.classList.toggle('active');
  mobileToggle.setAttribute('aria-expanded', isOpen);
});

function closeMobileMenu() {
  mobileMenu.classList.remove('active');
  mobileToggle.setAttribute('aria-expanded', 'false');
}

// Close mobile menu when clicking outside the header
document.addEventListener('click', (e) => {
  if (!header.contains(e.target) && mobileMenu.classList.contains('active')) {
    closeMobileMenu();
  }
});


/* ============================================
   3. FAQ ACCORDION
   Click question to expand/collapse answer
   Only one item open at a time
   ============================================ */
function toggleFaq(button) {
  const item = button.parentElement;
  const isActive = item.classList.contains('active');

  // Close all FAQ items first
  document.querySelectorAll('.faq-item').forEach(faq => faq.classList.remove('active'));

  // Open clicked item if it wasn't already active
  if (!isActive) {
    item.classList.add('active');
  }
}


/* ============================================
   4. SCROLL REVEAL ANIMATIONS
   Elements with .fade-up class animate in when
   they enter the viewport (IntersectionObserver)
   ============================================ */
const observerOptions = {
  root: null,
  rootMargin: '0px',
  threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, observerOptions);

document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));


/* ============================================
   5. BOOKING FORM HANDLER
   Sends data to Formspree (or your chosen backend)
   Shows loading state on button while sending
   ============================================ */
function handleBooking(e) {
  e.preventDefault();

  const form = e.target;
  const submitBtn = form.querySelector('button[type="submit"]');
  const originalText = submitBtn.textContent;

  // Show loading state
  submitBtn.textContent = 'Sending...';
  submitBtn.disabled = true;

  fetch(FORMSPREE_BOOKING_URL, {
    method: 'POST',
    body: new FormData(form),
    headers: { 'Accept': 'application/json' }
  })
  .then(response => {
    if (response.ok) {
      alert('Thank you! Your booking request has been sent. We will contact you shortly to confirm.');
      form.reset();
    } else {
      alert('Something went wrong. Please try again or call us directly.');
    }
  })
  .catch(() => {
    alert('Something went wrong. Please try again or call us directly.');
  })
  .finally(() => {
    submitBtn.textContent = originalText;
    submitBtn.disabled = false;
  });
}


/* ============================================
   6. APPLICATION FORM HANDLER
   Same pattern as booking form
   ============================================ */
function handleApplication(e) {
  e.preventDefault();

  const form = e.target;
  const submitBtn = form.querySelector('button[type="submit"]');
  const originalText = submitBtn.textContent;

  submitBtn.textContent = 'Sending...';
  submitBtn.disabled = true;

  fetch(FORMSPREE_APPLICATION_URL, {
    method: 'POST',
    body: new FormData(form),
    headers: { 'Accept': 'application/json' }
  })
  .then(response => {
    if (response.ok) {
      alert('Thank you! Your application has been submitted. Our team will review it and contact you soon.');
      form.reset();
    } else {
      alert('Something went wrong. Please try again or email us directly.');
    }
  })
  .catch(() => {
    alert('Something went wrong. Please try again or email us directly.');
  })
  .finally(() => {
    submitBtn.textContent = originalText;
    submitBtn.disabled = false;
  });
}


/* ============================================
   7. BOOKING DATE — MIN = TODAY
   Prevents users from selecting past dates
   ============================================ */
const dateInput = document.getElementById('book-date');
if (dateInput) {
  const today = new Date().toISOString().split('T')[0];
  dateInput.setAttribute('min', today);
}


/* ============================================
   8. SMOOTH SCROLL FOR ANCHOR LINKS
   All links starting with # scroll smoothly
   ============================================ */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const targetId = this.getAttribute('href');
    if (targetId === '#') return;

    const targetElement = document.querySelector(targetId);
    if (targetElement) {
      e.preventDefault();
      targetElement.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});
